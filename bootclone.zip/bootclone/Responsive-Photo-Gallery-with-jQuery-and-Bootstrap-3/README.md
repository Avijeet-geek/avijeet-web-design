# bootstrap-photo-gallery
Responsive photo gallery using the grid system of Bootstrap and custom jQuery for the modal

Files from the tutorial :and 

"How to create a responsive photo gallery using Bootstrap" :
http://fearlessflyer.com/create-a-responsive-photo-gallery-with-bootstrap-framework/

and 

"Let’s Add Next and Previous Buttons to our Bootstrap Photo Gallery"
http://fearlessflyer.com/next-and-previous-buttons-bootstrap-photo-gallery/

To view the demo: 
http://demo.fearlessflyer.com/html/demo/bootstrap-photo-gallery/
